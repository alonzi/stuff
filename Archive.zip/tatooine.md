This mission is to watch over Luke Skywalker as he grows up.
Adopt the pseudonym Old Ben.
