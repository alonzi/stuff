#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Mar 27 10:39:46 2018

@author: lpa2a
"""

fruit = "apple"

print(fruit)

print(fruit[3])
print(fruit[1:4])
print(fruit[::2])

fruit = [25,'apple','banana',['cherries','cantalope']]
fruit[0]
fruit[1][1:5]
fruit[1][1:5][0]


cities = {'chicago':1,'washington':2}
cities['chicago']
cities[0]
cities['CHICAGO']



for x in range(10):
    print(x)
   print("hello")
    
print("done")


for city in cities:
    print(cities[city])
    
    
i=0
while i<10:
    print(i)
    i+=1
    
    
x = [1,2,3]
while len(x)>0:
    print(x.pop())


   
    
5==5
5==6
 
# == != > < >= <=

height = 198    #cm
if height > 185:
    print("you're taller than pete")
elif height==185:
    print("you're the same height as pete")
else:
    print("Pete's taller than you")    

import numpy   
    
print(numpy.random.randn())






